/**
 * Contains all the annotation classes used by JavaCPP.
 */
package com.googlecode.javacpp.annotation;
