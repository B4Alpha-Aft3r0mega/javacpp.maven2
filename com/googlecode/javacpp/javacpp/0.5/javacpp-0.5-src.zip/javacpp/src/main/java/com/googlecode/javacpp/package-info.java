/**
 * Contains the main set of classes for JavaCPP.
 */
package com.googlecode.javacpp;
